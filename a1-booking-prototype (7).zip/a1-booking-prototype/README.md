
# A1 Hair & Beauty — Booking Prototype (Firebase + Vanilla JS)

Quick prototype with two pages:
- `index.html` — Customer booking (select service, stylist, date/time, confirm)
- `admin.html` — Simple admin dashboard (list/update/cancel bookings)

## Tech
- Vanilla JS + Firestore (Firebase) + Firebase Hosting

## Setup

1) Create a Firebase project at https://console.firebase.google.com
   - Enable **Firestore** (in test mode for demo) and **Authentication** (Email/Password or Anonymous).

2) In `web/firebase.js`, paste your project config:
   ```js
   // Get this from Firebase Console -> Project settings -> General -> Your apps -> SDK setup
   export const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "YOUR_PROJECT.firebaseapp.com",
     projectId: "YOUR_PROJECT_ID",
     storageBucket: "YOUR_PROJECT.appspot.com",
     messagingSenderId: "YOUR_SENDER_ID",
     appId: "YOUR_APP_ID"
   };
   ```

3) Install Firebase CLI (if not already):
   ```bash
   npm install -g firebase-tools
   firebase login
   ```

4) Initialize hosting in this folder:
   ```bash
   firebase init hosting
   # when asked, use "dist" or the current folder as public directory; if you pick "dist",
   # move files into that folder or change to "."; do NOT rewrite URLs for single-page app.
   ```

5) Seed minimal data (services & stylists) via Admin page (Add Service / Add Stylist buttons) 
   or run a one-time seed from the browser console using `seedMinimalData()` (defined in `web/seed.js`).

6) Serve locally:
   ```bash
   firebase emulators:start
   ```
   or
   ```bash
   firebase deploy
   ```

## Firestore Structure
- `services` (name, duration_min, price_aud, active)
- `stylists` (full_name, specialty, active)
- `bookings` (customer_name, email, phone, service_id, stylist_id, date, start_time, end_time, status)

## Security Rules (dev-friendly)
See `firestore.rules`. For class demos, start permissive and tighten later.

## Notes
- Availability is simplified: fixed 30-min slots from opening to closing. Collisions prevented by checking existing bookings.
- Extend later with real rostered hours, blackout dates, SMS/email notifications, etc.

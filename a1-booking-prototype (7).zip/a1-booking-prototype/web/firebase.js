export const firebaseConfig = {
  apiKey: "AIzaSyAu2AoAC5z_vRYa0AovlQgDvm0m7E7Aytw",
  authDomain: "a1-appointment-booking.firebaseapp.com",
  projectId: "a1-appointment-booking",
  storageBucket: "a1-appointment-booking.firebasestorage.app",
  messagingSenderId: "519291660641",
  appId: "1:519291660641:web:484202e79f328704013d20",
  measurementId: "G-LSKCR1329N"
};
